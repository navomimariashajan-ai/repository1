#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <Windows.h>
#include "team.h" //<vector>,<string>,"player.h"
using namespace std;

class Game {
	public:
		Game();
		bool isFirstInnings;

		int playersPerTeam;
		int maxBalls;
		int totalPlayers;
		int firstTeamRuns;

		Team teamA,teamB;
		Team *battingTeam,*bowlingTeam;
		Player *batsman,*bowler;
		std::string player[11];

		void Welcome();
		void ShowAllPlayers(string[]);
		int TakeIntegerInput();
		void SelectTeamPlayers();
		bool ValidatePlayer(int);
		void showTeamPlayers();

		void Toss();
		void TossChoice(Team);
		void startFirstInnings();
		void Initializer();
		void playInnings();
		void bat();
		bool validateInningsScore();
		void showGameScorecard();
		void startSecondInnings();
		void swap();
		void showMatchSummary();
};
