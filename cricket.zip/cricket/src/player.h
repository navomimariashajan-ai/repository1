#include<iostream>
#include <cstring>

class Player{
	public:
		Player();
		std :: string Name;
		int id;
		int runsScored;
		int ballsPlayed;
		int ballsBowled;
		int runsGiven;
		int wicketsTaken;

};



