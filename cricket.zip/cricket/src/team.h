
#include <vector>
#include "player.h"

class Team {
	public:
		std::string name;
		int totalRuns;
		int WicketsLost;
		int totalBallsBowled;
		std::vector <Player> player;
		Team();

};
