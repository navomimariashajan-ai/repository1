#include "game.h"
#include<unistd.h>
using namespace std;

Game::Game() { // @suppress("Class members should be properly initialized")
		playersPerTeam=4;
		maxBalls=6;
		totalPlayers=11;

		player[0]="Virat  ";
		player[1]="Sachin  ";
		player[2]="Rohit   ";
		player[3]="Rani     ";
		player[4]="Alaina  ";
		player[5]="Gayatri ";
		player[6]="Sherlock";
		player[7]="Nezuko  ";
		player[8]="Tanjiro ";
		player[9]="Muzan   ";
		player[10]="Akaza   ";

		isFirstInnings=false;
		teamA.name="Team-A";
		teamB.name="Team-B";

};
void Game::Welcome() {
	cout<<"------------------------------------------------"<<endl;
	cout<<"|==============================================|"<<endl;
	cout<<"|                                              |"<<endl;
	cout<<"|       Welcome to Virtual Cricket Game        |"<<endl;
	cout<<"|==============================================|"<<endl;
	cout<<"------------------------------------------------"<<endl;

	Sleep(500);

	cout<<"------------------------------------------------"<<endl;
	cout<<"|=================Instructions=================|"<<endl;
	cout<<"------------------------------------------------"<<endl;
	cout<<"|                                              |"<<endl;
	cout<<"|1. Create 2 teams (Team-A and Team-B with 4   |"<<endl;
	cout<<"|players each) from a given pool of 11 players.|"<<endl;
	cout<<"|2.Lead the toss and decide the choice of play.|"<<endl;
	cout<<"| 3.Each innings will be 6 balls.              |"<<endl;
	cout<<"------------------------------------------------"<<endl;
}


void Game::ShowAllPlayers(string player[]) {
	cout<<"------------------------------------------------"<<endl;
	cout<<"|================Pool of Players===============|"<<endl;
	cout<<"------------------------------------------------"<<endl;
	for(int i=0;i<11;i++) {
		cout<<"                     ["<<i<<"]"<<player[i]<<"                   "<<endl;
		Sleep(499);
		}
}
int Game::TakeIntegerInput() {
	int n;

	while(!(cin >> n)) {
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(),'\n');
		cout<<"Invalid Input \nenter integer input:";
	}
	return n;
}
void Game::SelectTeamPlayers() {
	cout<<"------------------------------------------------"<<endl;
	cout<<"|=================Player Selection==============|"<<endl;
	cout<<"------------------------------------------------"<<endl;
	cout<<"Team A"<<endl;
	cout<<"-------"<<endl;

	for(int i=0;i<4;i++) {
		TeamASelection:
		cout<<"enter player"<<i+1<<":";
		int playerTeamA=TakeIntegerInput();

		if((playerTeamA>10)||(playerTeamA<0)) {
			cout<<"please select from given no. of players"<<endl;
			goto TeamASelection ;
		}
		else if(!(ValidatePlayer(playerTeamA))) {
			cout<<"player "<<playerTeamA<<" was already selected.\n";
			goto TeamASelection;
		}
		else {
			Player teamAPlayer;
			teamAPlayer.id=playerTeamA;
			teamAPlayer.Name=player[playerTeamA];
			teamA.player.push_back(teamAPlayer);
		}
	}

	cout<<"Team B"<<endl;
	cout<<"-------"<<endl;
	for(int i=0;i<4;i++) {
		TeamBSelection:
		cout<<"enter player"<<i+1<<":";
		int playerTeamB=TakeIntegerInput();

		if((playerTeamB>10)||(playerTeamB<0)) {
				cout<<"please select from given no. of players"<<endl;
				goto TeamBSelection ;
		}
		else if(!(ValidatePlayer(playerTeamB))) {
				cout<<"player "<<playerTeamB<<" was already selected.\n";
				goto TeamBSelection;
			}
		else {
			Player teamBPlayer;
			teamBPlayer.id=playerTeamB;
			teamBPlayer.Name=player[playerTeamB];
			teamB.player.push_back(teamBPlayer);
		}
	}
}
bool Game::ValidatePlayer(int index) {
	int n;
	vector<Player> player;

	player=teamA.player;
	n=player.size();
	for(int i=0;i<n;i++) {
		if(player[i].id==index) {
			return false;
		}
	}
	player=teamB.player;
	n=player.size();
	for(int i=0;i<n;i++) {
		if(player[i].id==index) {
			return false;
		}
	}return true;
}
void Game::showTeamPlayers() {
	vector<Player> player1,player2;
	cout<<"------------------------------------------------"<<endl;
	cout<<"----------"<<"\t\t"<<"----------\n";
	cout<<"| Team A |"<<"\t\t"<<"| Team B |\n";
	cout<<"----------"<<"\t\t"<<"----------\n";
	player1=teamA.player;
	player2=teamB.player;
	for(int i=0;i<4;i++) {
		std::cout << i+1 <<"."<<player1[i].Name<<"\t\t";
		std::cout<<i+1<<"."<<player2[i].Name<<"\n";
		cout<<"----------"<<"\t\t"<<"----------\n";
	}
	cout<<"------------------------------------------------"<<endl;
}
void Game::Toss() {
	cout<<"------------------------------------------------"<<endl;
	cout<<"|=================Starting Tossing==============|"<<endl;
	cout<<"------------------------------------------------"<<endl;

	Sleep(501);

	cout<<"\n";
	cout<<"Tossing the coin....\n";
	Sleep(1499);
	srand(time(NULL));
	int randomValue=(rand()%2);
	switch(randomValue) {
		case 0:
			cout<<"Team A wins\n";
			Sleep(500);
			TossChoice(teamA);
			break;
		case 1:
			cout<<"Team B wins\n";
			Sleep(500);
			TossChoice(teamB);
			break;
	}
}
void Game::TossChoice(Team tossWinner) {
	cout<<"------------------------------------------------"<<endl;
	cout<<"|=================Choose from 1or2==============|"<<endl;
	cout<<"------------------------------------------------"<<endl;
	Sleep(510);
	cout<<"1.Batting\n"<<"2.Bowling\n";

	int choice=TakeIntegerInput();

	switch(choice) {
		case 1:
			if(tossWinner.name.compare("Team-A")==0) {
				cout<<tossWinner.name<<" wins the toss and has chosen BATTING";
				battingTeam =&teamA;
				bowlingTeam = &teamB;
			}else {
				cout<<tossWinner.name<<" wins the toss and has chosen BATTING";
				battingTeam =&teamB;
				bowlingTeam = &teamA;
			}
			break;
		case 2 :

			if(tossWinner.name.compare("Team-A")==0) {
				cout<<tossWinner.name<<" wins the toss and has chosen BOWLING";
				battingTeam =&teamA;
				bowlingTeam = &teamB;
			}else {
				cout<<tossWinner.name<<" wins the toss and has chosen BOWLING";
				battingTeam =&teamB;
				bowlingTeam = &teamA;
			}
			break;
		default:
			cout<<"Invalid Choice\nChoose from 1 or 2";
			TossChoice(tossWinner);
	}

}
void Game::startFirstInnings(){
	cout<<"\n\n\t\t|| FIRST INNING STARTS ||\n\n";
	Sleep(500);
	isFirstInnings=true;
	Initializer();
	playInnings();
}
void Game::Initializer() {

	batsman=&battingTeam->player[0];
	bowler=&bowlingTeam->player[0];

	cout<<battingTeam->name<<"-"<<batsman->Name<<" is batting\n";
	Sleep(500);
	cout<<bowlingTeam->name<<"-"<<bowler->Name<<" is bowling\n"<<endl;

}
void Game::playInnings(){
	for(int i=0;i<6;i++) {
		cout<<"Press enter to continue"<<endl<<endl;
		cin.get();
		cout<<"Bowling...\n";
		Sleep(499);
		bat();
		if(!validateInningsScore()) {
			isFirstInnings=false;
			break;
		}
	}
}
void Game::bat(){

	srand(time(NULL));
	int runsScored=rand()%7;

	//update batting team and batsman score
	batsman->runsScored=batsman->runsScored+runsScored;
	battingTeam->totalRuns+=runsScored;
	batsman->ballsPlayed+=1;

	//update bowling team and bowler score
	bowler->ballsBowled+=1;
	bowlingTeam->totalBallsBowled+=1;
	bowler->runsGiven+=runsScored;

	if(runsScored!=0) {
		cout<<endl<<bowler->Name<<" to "<<batsman->Name<<" "<<runsScored<<" runs!"<<endl<<endl;
		Sleep(500);
		showGameScorecard();
	}else {
		cout<<endl<<bowler->Name<<" to "<<batsman->Name<<" "<<"OUT"<<endl<<endl;

		battingTeam->WicketsLost+=1;
		bowler->wicketsTaken+=1;
		Sleep(500);
		showGameScorecard();

		int nextPlayerId=battingTeam->WicketsLost;
		batsman=&battingTeam->player[nextPlayerId];

	}
}
bool Game::validateInningsScore() {
	if(isFirstInnings) {
		if(battingTeam->WicketsLost==playersPerTeam || bowlingTeam->totalBallsBowled==maxBalls) {
			cout << "\t\t ||| FIRST INNINGS ENDS ||| " << endl << endl;
			Sleep(500);
			cout << battingTeam->name << " " << battingTeam->totalRuns << " - "
					<< battingTeam->WicketsLost << " (" << bowlingTeam->totalBallsBowled
								<< ")" << endl;

			cout << bowlingTeam->name << " needs " << battingTeam->totalRuns + 1
				 << " runs to win the match" << endl << endl;
			firstTeamRuns=battingTeam->totalRuns;
			return false;
		}
	}
	else {
		if(battingTeam->WicketsLost==playersPerTeam || bowlingTeam->totalBallsBowled==maxBalls|| battingTeam->totalRuns > firstTeamRuns) {
			cout << "\t\t ||| SECOND INNINGS ENDS ||| " << endl << endl;
			Sleep(500);
			cout << battingTeam->name << " " << battingTeam->totalRuns << " - "
							<< battingTeam->WicketsLost << " (" << bowlingTeam->totalBallsBowled
										<< ")" << endl<<endl;


			if(teamA.totalRuns > teamB.totalRuns) {
				Sleep(500);
				cout<< teamA.name<<" WON !!!  with "<<teamA.totalRuns<<" runs\n";
			}
			else if (teamA.totalRuns == teamB.totalRuns){
				Sleep(500);
				cout<<"It's a TIE!!!"<<endl<<endl;
			}
			else{
				Sleep(500);
				cout<< teamB.name<<" WON !!!  with "<<teamB.totalRuns<<" runs\n";
			}
			cout<<endl;
			Sleep(500);
			cout << "----------------------Match Ends--------------------------------" << endl;
			return false;
		   }
	}
	return true;
}
void Game::showGameScorecard() {

    cout << "--------------------------------------------------------------------------" << endl;

    cout << "\t" << battingTeam->name << "  " << battingTeam->totalRuns << " - "
      << battingTeam->WicketsLost << " (" << bowlingTeam->totalBallsBowled << ") | " << batsman->Name
      << " " << batsman->runsScored << " (" << batsman->ballsPlayed << ") \t" << bowler->Name << " "
	  << bowler->ballsBowled << " - " << bowler->runsGiven << " - " << bowler->wicketsTaken << "\t" << endl;

    cout << "--------------------------------------------------------------------------" << endl << endl;
}
void Game::startSecondInnings() {
	cout<<"\t\t|| SECOND INNING STARTS ||\n\n";
	swap();

	Initializer();
	playInnings();
}
void Game::swap() {
	Team *temp=battingTeam;
	battingTeam=bowlingTeam;
	bowlingTeam=temp;
}
void Game::showMatchSummary(){
	cout << "--------------------------------------------------------------------------" << endl;
	cout<<teamA.name<<" "<<teamA.totalRuns<<"-"<<teamA.WicketsLost<<endl;
	cout << "---------------------------------------" << endl;
	cout << "|Player  |"<<"\tBatting |"<<"\tBowling|" << endl;
	cout << "---------------------------------------" << endl;
	for(int i=0;i<4;i++){
		cout<<"|"<<teamA.player[i].Name<<"\t"<<teamA.player[i].runsScored<<"("<<teamA.player[i].ballsPlayed<<")\t";
		cout<<teamA.player[i].ballsBowled<<"-"<<teamA.player[i].runsGiven<<"-"<<teamA.player[i].wicketsTaken<<"|"<<endl;

		cout << "---------------------------------------" << endl<<endl<<endl;
	}
	cout << "--------------------------------------------------------------------------" << endl;
	cout<<teamB.name<<" "<<teamB.totalRuns<<"-"<<teamB.WicketsLost<<endl;
	cout << "---------------------------------------" << endl;
	cout << "|Player  |"<<"\tBatting |"<<"Bowling|" << endl;
	cout << "---------------------------------------" << endl;
	for(int i=0;i<4;i++){
	cout<<"|"<<teamB.player[i].Name<<"\t"<<teamB.player[i].runsScored<<"("<<teamB.player[i].ballsPlayed<<")\t";
	cout<<teamB.player[i].ballsBowled<<"-"<<teamB.player[i].runsGiven<<"-"<<teamB.player[i].wicketsTaken<<"|"<<endl;

	cout << "---------------------------------------" << endl<<endl;
		}
}
