
#include "team.h"  //player.h,string,vector

Team::Team()  {

	totalRuns=0;
	WicketsLost=0;
	totalBallsBowled=0;
};


