//============================================================================
// Name        : cricket.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "game.h"
using namespace std;

int main() {
	Game game;
	game.Welcome();

	cout<<"Press enter to continue"<<endl<<endl;
	cin.get();

	game.ShowAllPlayers(game.player);
	cout<<"Press enter to continue"<<endl<<endl;
	cin.get();

	game.SelectTeamPlayers();
	game.showTeamPlayers();

	cin.ignore(numeric_limits<streamsize>::max(),'\n');
	cout<<"Press enter to TOSS"<<endl<<endl;
	cin.get();

	game.Toss();

	cin.ignore(numeric_limits<streamsize>::max(),'\n');
	game.startFirstInnings();
	game.startSecondInnings();
	game.showMatchSummary();

	return 0;
}
